# Product-Reccomendation-Model
Our model automates recommendations from our product database and sends them to users via WhatsApp and email at regular intervals. 
Our highly efficient model takes care of automating recommendations from our vast product database, and we are proud to say that it does so with remarkable ease and accuracy.

These personalized recommendations are then dispatched to our esteemed users on a regular basis, via both WhatsApp and email, ensuring that they never miss out on any of our exciting product offerings.
